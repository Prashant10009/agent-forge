import json
import logging
from typing import Dict, Any
import src.projects.doc_extractor.doc_extractor as doc_extractor

class Orchestrator:
    def __init__(self, model_client):
        self.model_client = model_client
        self.logger = logging.getLogger(__name__)

    def llm_classify_and_extract(self, file_path: str) -> Dict[str, Any]:
        """Classify a document and extract structured fields using LLM.
        
        Args:
            file_path: Path to the document file to process
            
        Returns:
            Dictionary with:
            - document_type: str classification
            - classification_confidence: float (0.0-1.0)
            - extracted_fields: dict of key-value pairs
            - text_snippet: first ~200 chars of text
        """
        try:
            extracted = doc_extractor.extract(file_path)
            text = extracted.get('text', '')
            snippet = text[:200] if text else ''

            prompt = (
                "Analyze this document and return ONLY valid JSON with:\n"
                "- document_type (string category)\n"
                "- classification_confidence (float 0.0-1.0)\n"
                "- extracted_fields (JSON object of key:value pairs)\n"
                "- text_snippet (first ~200 chars)\n\n"
                "Return format MUST be:\n"
                '{\n'
                '    "document_type": "...",\n'
                '    "classification_confidence": 0.0,\n'
                '    "extracted_fields": {},\n'
                '    "text_snippet": "..."\n'
                '}\n\n'
                "Document text:\n" + text + "\n\n"
                "Return ONLY JSON, no markdown or comments."
            )

            response = self.model_client.chat(prompt)
            return self._parse_llm_response(response, snippet)

        except Exception as e:
            self.logger.error(f"Document processing failed: {e}")
            return self._default_extraction_result(text[:200] if 'text' in locals() else '')

    def _parse_llm_response(self, response: str, fallback_snippet: str) -> Dict[str, Any]:
        """Parse LLM response JSON and validate structure."""
        try:
            data = json.loads(response)
            if not all(key in data for key in ['document_type', 'classification_confidence', 'extracted_fields', 'text_snippet']):
                raise ValueError("Missing required keys in LLM response")
            
            return {
                'document_type': str(data['document_type']),
                'classification_confidence': float(data['classification_confidence']),
                'extracted_fields': dict(data['extracted_fields']),
                'text_snippet': str(data.get('text_snippet', fallback_snippet))
            }
        except (json.JSONDecodeError, ValueError, TypeError) as e:
            self.logger.error(f"Failed to parse LLM response: {e}")
            return self._default_extraction_result(fallback_snippet)

    def _default_extraction_result(self, snippet: str) -> Dict[str, Any]:
        """Return safe default when extraction fails."""
        return {
            'document_type': 'unknown',
            'classification_confidence': 0.0,
            'extracted_fields': {},
            'text_snippet': snippet
        }

    def run_document_extractor(self, file_path: str) -> Dict[str, Any]:
        """Process document through both extractor and classifier."""
        return self.llm_classify_and_extract(file_path)

    def generate_file(self, *args, **kwargs):
        pass

    def generate_and_run(self, *args, **kwargs):
        pass

    def plan_and_build_project(self, *args, **kwargs):
        pass