"""Document extraction and classification module."""

import io
import logging
import os.path
import re
from pathlib import Path
from typing import Dict, Optional, Tuple, Union

logger = logging.getLogger(__name__)

SUPPORTED_TEXT_EXTENSIONS = {'.txt'}
SUPPORTED_PDF_EXTENSIONS = {'.pdf'}
SUPPORTED_IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.tif', '.bmp'}

DOCUMENT_TYPES = [
    'insurance_policy',
    'insurance_claim',
    'bank_statement',
    'police_report',
    'invoice',
    'unknown'
]

class ExtractionError(Exception):
    """Raised when document extraction fails."""
    pass

class ClassificationError(Exception):
    """Raised when document classification fails."""
    pass

class MissingDependencyError(ImportError):
    """Required dependency is not installed."""
    pass

def extract(file_path: str) -> str:
    """
    Extract text content from a file.
    
    Args:
        file_path: Path to the input file
        
    Returns:
        Extracted text content as string
        
    Raises:
        ExtractionError: If extraction fails or file type is unsupported
        MissingDependencyError: If required dependencies are missing
        FileNotFoundError: If file doesn't exist
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Document file not found: {file_path}")

    path = Path(file_path)
    suffix = path.suffix.lower()
    
    if suffix in SUPPORTED_TEXT_EXTENSIONS:
        return _extract_text(path)
    elif suffix in SUPPORTED_PDF_EXTENSIONS:
        return _extract_pdf(path)
    elif suffix in SUPPORTED_IMAGE_EXTENSIONS:
        return _extract_image(path)
    else:
        raise ExtractionError(f"Unsupported file extension: {suffix}")

def _extract_text(path: Path) -> str:
    """Extract text from plaintext file."""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except UnicodeDecodeError:
        with open(path, 'r', encoding='latin-1') as f:
            return f.read()
    except Exception as e:
        raise ExtractionError(f"Failed to read text file: {str(e)}")

def _extract_pdf(path: Path) -> str:
    """Extract text from PDF file."""
    try:
        import pdfplumber
    except ImportError as e:
        raise MissingDependencyError(
            "PDF extraction requires pdfplumber. Install with: pip install pdfplumber"
        ) from e
    
    try:
        with pdfplumber.open(path) as pdf:
            pages = []
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    pages.append(text)
            return "\n".join(pages)
    except Exception as e:
        raise ExtractionError(f"Failed to extract PDF text: {str(e)}")

def _extract_image(path: Path) -> str:
    """Extract text from image file."""
    try:
        from PIL import Image
        import pytesseract
    except ImportError as e:
        raise MissingDependencyError(
            "Image extraction requires Pillow and pytesseract. "
            "Install with: pip install pillow pytesseract"
        ) from e
    
    try:
        with Image.open(path) as img:
            return pytesseract.image_to_string(img)
    except Exception as e:
        raise ExtractionError(f"Failed to perform OCR on image: {str(e)}")

def classify(text: str) -> Tuple[str, float]:
    """
    Classify document based on extracted text.
    
    Args:
        text: Extracted text content
        
    Returns:
        Tuple of (document_type, confidence) where confidence is between 0 and 1
        
    Raises:
        ClassificationError: If classification fails
    """
    if not text or not isinstance(text, str):
        return ('unknown', 0.0)
    
    text_lower = text.lower()
    
    document_types = [
        ('insurance_policy', _is_insurance_policy),
        ('insurance_claim', _is_insurance_claim),
        ('bank_statement', _is_bank_statement),
        ('police_report', _is_police_report),
        ('invoice', _is_invoice)
    ]
    
    best_type = 'unknown'
    best_score = 0.0
    
    for doc_type, classifier in document_types:
        score = classifier(text_lower)
        if score > best_score:
            best_type = doc_type
            best_score = score
    
    if best_score > 0.7:  # Threshold for positive classification
        return (best_type, best_score)
    return ('unknown', 0.5)

def _is_insurance_policy(text: str) -> float:
    keywords = ['policy', 'coverage', 'premium', 'deductible', 'insurance']
    return _text_contains_keywords(text, keywords)

def _is_insurance_claim(text: str) -> float:
    keywords = ['claim', 'incident', 'damage', 'adjuster', 'settlement']
    return _text_contains_keywords(text, keywords)

def _is_bank_statement(text: str) -> float:
    keywords = ['statement', 'account', 'balance', 'transaction', 'withdrawal']
    patterns = [r'\d{2}/\d{2}.*\$\d+\.\d{2}']  # Date followed by amount
    return max(
        _text_contains_keywords(text, keywords),
        _text_contains_patterns(text, patterns)
    )

def _is_police_report(text: str) -> float:
    keywords = ['incident', 'report', 'officer', 'witness', 'complaint']
    return _text_contains_keywords(text, keywords)

def _is_invoice(text: str) -> float:
    keywords = ['invoice', 'total', 'amount', 'due', 'tax']
    patterns = [r'invoice\s*#?\s*\d+', r'total\s*\$\d+\.\d{2}']
    return max(
        _text_contains_keywords(text, keywords),
        _text_contains_patterns(text, patterns)
    )

def _text_contains_keywords(text: str, keywords: list) -> float:
    """Return confidence score based on keyword matches."""
    matches = sum(1 for kw in keywords if kw in text)
    return min(1.0, matches / len(keywords) * 1.5)  # Scale to 0-1 range

def _text_contains_patterns(text: str, patterns: list) -> float:
    """Return confidence score based on regex pattern matches."""
    matches = sum(1 for pat in patterns if re.search(pat, text))
    return min(1.0, matches / len(patterns) * 1.5)

def process(file_path: str) -> Dict[str, Union[str, float, Dict]]:
    """
    Process a document file by extracting text and classifying it.
    
    Args:
        file_path: Path to the input file
        
    Returns:
        Dictionary with processing results containing:
        - document_type: str
        - classification_confidence: float
        - extracted_fields: dict (placeholder for future field extraction)
        - text_snippet: str (first 200 chars of text)
        
    Raises:
        ExtractionError: If text extraction fails
        ClassificationError: If classification fails
    """
    try:
        extracted_text = extract(file_path)
        doc_type, confidence = classify(extracted_text)
        
        return {
            'document_type': doc_type,
            'classification_confidence': confidence,
            'extracted_fields': _extract_fields(doc_type, extracted_text),
            'text_snippet': extracted_text[:200].strip() if extracted_text else ''
        }
    except Exception as e:
        logger.error(f"Failed to process document: {str(e)}")
        raise

def _extract_fields(doc_type: str, text: str) -> Dict:
    """Extract relevant fields based on document type."""
    if doc_type == 'unknown':
        return {}
    
    extractors = {
        'insurance_policy': _extract_insurance_policy_fields,
        'insurance_claim': _extract_insurance_claim_fields,
        'bank_statement': _extract_bank_statement_fields,
        'police_report': _extract_police_report_fields,
        'invoice': _extract_invoice_fields
    }
    
    return extractors.get(doc_type, lambda _: {})(text)

def _extract_insurance_policy_fields(text: str) -> Dict:
    return {
        'policy_number': _extract_pattern(text, r'policy\s*#?\s*([A-Z0-9-]+)'),
        'effective_date': _extract_pattern(text, r'effective\s*date:\s*(\d{2}/\d{2}/\d{4})'),
        'premium_amount': _extract_pattern(text, r'premium\s*amount:\s*(\$\d+\.\d{2})')
    }

def _extract_insurance_claim_fields(text: str) -> Dict:
    return {
        'claim_number': _extract_pattern(text, r'claim\s*#?\s*([A-Z0-9-]+)'),
        'date_of_loss': _extract_pattern(text, r'date\s*of\s*loss:\s*(\d{2}/\d{2}/\d{4})'),
        'claim_amount': _extract_pattern(text, r'claim\s*amount:\s*(\$\d+\.\d{2})')
    }

def _extract_bank_statement_fields(text: str) -> Dict:
    return {
        'account_number': _extract_pattern(text, r'account\s*#?\s*([X\d-]+)'),
        'statement_date': _extract_pattern(text, r'statement\s*date:\s*(\d{2}/\d{2}/\d{4})'),
        'ending_balance': _extract_pattern(text, r'ending\s*balance:\s*(\$\d+\.\d{2})')
    }

def _extract_police_report_fields(text: str) -> Dict:
    return {
        'report_number': _extract_pattern(text, r'report\s*#?\s*([A-Z0-9-]+)'),
        'incident_date': _extract_pattern(text, r'date\s*of\s*incident:\s*(\d{2}/\d{2}/\d{4})'),
        'officer_name': _extract_pattern(text, r'officer\s*name:\s*([A-Z][a-z]+\s[A-Z][a-z]+)')
    }

def _extract_invoice_fields(text: str) -> Dict:
    return {
        'invoice_number': _extract_pattern(text, r'invoice\s*#?\s*([A-Z0-9-]+)'),
        'invoice_date': _extract_pattern(text, r'date:\s*(\d{2}/\d{2}/\d{4})'),
        'total_amount': _extract_pattern(text, r'total\s*amount:\s*(\$\d+\.\d{2})')
    }

def _extract_pattern(text: str, pattern: str) -> Optional[str]:
    """Helper to extract first match from text using regex pattern."""
    match = re.search(pattern, text, re.IGNORECASE)
    return match.group(1) if match else None