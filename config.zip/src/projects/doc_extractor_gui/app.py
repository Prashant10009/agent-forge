import streamlit as st
import tempfile
import os
import json
import doc_extractor

def main():
    st.title("Document Extractor")
    st.write("Upload a document to extract structured data")

    uploaded_file = st.file_uploader("Choose a file", type=["pdf", "docx", "pptx"])
    
    if uploaded_file is not None:
        try:
            with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(uploaded_file.name)[1]) as tmp_file:
                tmp_file.write(uploaded_file.getbuffer())
                tmp_path = tmp_file.name

            result = doc_extractor.process(tmp_path)
            
            st.subheader("Extracted Data")
            st.json(result)
            
            st.subheader("Raw JSON")
            st.code(json.dumps(result, indent=2), language='json')
            
        except Exception as e:
            st.error(f"An error occurred: {str(e)}")
        finally:
            if 'tmp_path' in locals() and os.path.exists(tmp_path):
                os.unlink(tmp_path)

if __name__ == "__main__":
    main()