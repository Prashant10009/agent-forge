def main():
    print("Hello from the config-driven agent factory!")

if __name__ == '__main__':
    main()