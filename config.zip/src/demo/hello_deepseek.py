def main():
    print('Hello from the main agent, powered by DeepSeek via OpenRouter!')

if __name__ == '__main__':
    main()