def hello_run():
    print("Hello from the run pipeline!")

if __name__ == "__main__":
    hello_run()