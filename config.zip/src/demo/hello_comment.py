# hello_comment.py
"""This script prints a simple greeting message."""

def main():
    print('Hello with a header comment')

if __name__ == '__main__':
    main()